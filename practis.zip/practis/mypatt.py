n=5
for i in range(1,5):
    print(" "*n,end="")
    print("*"*i)
    n=n-1