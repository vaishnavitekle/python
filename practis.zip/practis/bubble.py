nos=int(input("enter no of students"))
start=0
end=nos-1
present=[]
print("enter present students roll no")
for i in range(0,nos):
    b=int(input(""))
    present.append(b)
    present.sort()
key=int(input("enter roll no u want to search"))
flag=False
def binary(present,start,end):
     if (start<=end):
         mid=int((start+end)/2)
         if (key==present[mid]):
             print("roll no found at position",mid)
             flag=True
         elif(key>present[mid]):
             binary(present,mid+1,end)
         elif(key<present[mid]):
              binary(present,start,mid-1)
     else:
        print("roll no not found")
binary(present,start,end)


