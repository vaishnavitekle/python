def bubble(arr,n):
    for i in range(0,n):
        for j in range(i+1,n):
            if(arr[j]<arr[i]):
                t=arr[i]
                arr[i]=arr[j]
                arr[j]=t

'''def selection(arr,n):
    n=len(arr)
    for i in range(0,n):
        m=i
        for j in range(0,n):
            if(arr[m]>arr[j]):
                m=j
            t=arr[i]
            arr[i]=arr[m]
            arr[m]=t

def max(arr,n):
    ma=arr[0]
    for i in range(1,n):
        if(arr[i]>ma):
            ma=arr[i]
    return ma
def count(arr,pl):
    s=len(arr)
    out=[0]*s
    c=[0]*10
    for i in range(0,s):
        ind=arr[i]//pl
        c[ind%10]+=1
        print(c)
    for i in range(1,10):
        c[i]+=c[i-1]
        print(c)
    i=s-1
    while i>=0:
        ind=arr[i]//pl
        out[c[ind%10]-1]=arr[i]
        c[ind%10]-=1
        i-=1
        print(c)
        print(out)
    for i in range(0,s):
        arr[i]=out[i]
def radix(arr):
    n=len(arr)
    m=max(arr,n)
    i=1
    while m//i>0:
        count(arr,i)
        i=i*10

arr=[10,20,22,11,15,17]
radix(arr)
for i in range(len(arr)):
    print(arr[i])
'''
arr=[10,20,22,11,15,17]
n=len(arr)
bubble(arr,n)
for i in range(len(arr)):
    print(arr[i])