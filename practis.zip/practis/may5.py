a="diksha"
for i in a:
    print(i)
    if(i=='k'):
        print("this ia somethig special")