def selection(arr,n):
    n=len(arr)
    for i in range(0,n):
        m=i
        for j in range(0,n):
            if(arr[m]>arr[j]):
                m=j
            t=arr[i]
            arr[i]=arr[m]
            arr[m]=t
nos=int(input("enter no of students"))
arr=[]
print("enter present students roll no")
for i in range(0,nos):
    b=int(input(""))
    arr.append(b)
    arr.sort()
selection(arr,nos)
for i in range(len(arr)):
    print(arr[i])