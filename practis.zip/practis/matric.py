row=int (input("enter the no of rows:"))
col= int (input("Enter the no of colums:"))

a= []
b=[]

ans=[[0,0,0],
     [0,0,0],
     [0,0,0]]

ans1=[[0,0,0],
     [0,0,0],
     [0,0,0]]

ans2=[[0,0,0],
     [0,0,0],
     [0,0,0]]
print("Enter the value in First matrix :")
for i in range(row):
    r= []
    for j in range(col):
        r.append(int(input()))
    a.append(r)

print ("Enter the value in 2nd matrix:")

for i in range(row):
    s=[]
    for j in range(col):
        s.append(int(input()))
    b.append(s)
    
for i in range (row):
    for j in range(col):
        print(a[i][j],end=" ")
    print()

    
for i in range (row):
    for j in range(col):
        print(b[i][j],end=" ")
    print()
        
print("transpose of matrix a:")

for i in range(len(a)):
    for j in range(len(a)):
        ans[i][j]=a[j][i]

for l in ans:
    print(l)


print ("transpose of matrix b:")

for i in range(len(b)):
    for j in range(len(b)):
        ans1[i][j]=b[j][i]
        
for p in ans1:
    print(p)
        
print ("multiplication :")

for i in range(len(a)):
    for j in range(len(b)):
        for k in range(len(b)):
            ans2[i][j]+=a[i][k]*b[j][k]

for q in ans2:
    print(q)
    
print("addition of matrix:")

for i in range(len(a)):
    for j in range(len(b)):
        ans=a[i][j]+b[i][j]
        print(ans,end=" ")
    print()
    
print("substraction of matrix:")

for i in range(len(a)):
    for j in range(len(b)):
        ans=a[i][j]-b[i][j]
        print(ans,end=" ")
    print()