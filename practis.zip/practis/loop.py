a=1
while (a<10):
    print(a)
    a=a+1


for i in range(2,10,2):
    print(i)