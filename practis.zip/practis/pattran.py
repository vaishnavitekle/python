n=5
for i in range(5):
    print(" " * (n-i-1),end="")
    print("*" * (2*i+1),end="")
    print(" " * (n-i-1))

 

# n=3
# for i in range(5):
#     print("*" * (i))

# for i in range(4,0,-1):
#     print("*" * (i))

