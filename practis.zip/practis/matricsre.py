x1=int(input("enter no of row"))
y1=int(input("enter no of collomn"))
m=[]
for i in range(y1):
    a=[]
    for j in range(x1):
        a.append(int(input()))
    m.append(a)
print(m)