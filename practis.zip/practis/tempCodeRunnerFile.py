def LS(arr,n,x):
    for i in range(0,n):
        if(arr[i]==x):
            return i
        return -1
y=int(input("enter student"))
arr=[]
print("enter student")
for i in range(0,y):
    a=[]
    aa=int(input())
    arr.apend(a)
x=int(input("enter the no you want to search"))
n=len(arr)
result=LS(arr,n,x)
if(result==-1):
   print("found")
else:
    print("found")