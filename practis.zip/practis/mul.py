x=[[10,20,30],[11,22,33],[9,19,29]]
y=[[7,27,37],[6,16,26],[5,15,25]]
re=[]
re1=[]
re2=[[0,0,0],[0,0,0],[0,0,0]]
x1=3
y1=3
x2=3
y2=3
print("addition")
if((x1==x2)and(y1==y2)):
    for i in range(0,3):
        for j in range(0,3):
            re=x[i][j]+y[i][j]
            print(re,end="")
        print()
print("subtraction")
if((x1==x2)and(y1==y2)):
    for i in range(0,3):
        for j in range(0,3):
            re1=x[i][j]-y[i][j]
            print(re1,end="")
        print()
print("multiplication")
for i in range(len(x)):
    for j in range(len(y)):
        for k in range(len(y)):
            re2[i][j]+=x[i][k]*y[k][j]
            
for r in re2:            
        print(r)    
