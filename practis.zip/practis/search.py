def binary(arr,i,n,x):
    if i<=n:
        m=int((i+n)/2)
        if arr[m]==x:
            return m
        elif arr[m]>x:
            return binary(arr,i,m-1,x)
        else:
            return binary(arr,m+1,n,x)
    else:
        return -1
y=int(input("enter student no of student"))
arr=[]
print("enter students roll no.")
for i in range(0,y):
    a=int(input())
    arr.append(a)
arr.sort()
print(arr)
n=len(arr)
x=int(input("enter the roll no of student you want to search"))
result=binary(arr,0,n,x)
if(result==-1):
   print("not found")
else:
    print("found",str(result))
