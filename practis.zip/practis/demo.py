a=int(input("enter number"))
if(a>9):
    print("greater")
elif(a<9):
    print("less")
else:
    print("equal to nine")