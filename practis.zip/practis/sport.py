group_c=[]
group_b=[]
group_f=[]
num1=int(input("Enter the number of players in Cricket Team :"))
for i in range(1,num1+1):
  element=input("Enter the name of student :")
  group_c.append(element)

num2=int(input("\nEnter the number of players in Badminton Team :"))
for i in range(1,num2+1):
  element=input("Enter the name of student :")
  group_b.append(element)

num3=int(input("\nEnter the number of players in Football Team :"))
for i in range(1,num3+1):
  element=input("Enter the name of student :")
  group_f.append(element)

print('CRICKET  LIST -->',group_c)
print('BADMINTON  LIST -->',group_b)
print('FOOTBALL  LIST -->',group_f)

def common(s1,s2):
  common_set=[]
  for i in s1:
    for j in s2:
      if i==j:
        common_set.append(j)
  return common_set

 
Union=group_c+group_b
both=common(group_c,group_b)
for i in Union:
  if i in both:
    Union.remove(i)
print("students who play either cricket or badminton but not both :")
print(Union)
print()


only_f=group_f
for i in group_f:
  if i in (group_c or group_b):
    only_f.remove(i)
print("students who play neither cricket nor badminton :")
print(only_f)
print()


Union=group_c+group_f
for i in Union:
  if i in group_b:
    Union.remove(i)
print("Students who play cricket and football but not badminton :")
print(Union)